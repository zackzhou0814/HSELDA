import torch
import torch.nn.functional as F
from torch.nn import Linear, Sequential, BatchNorm1d, ReLU, Dropout
from torch_geometric.nn import GCNConv, GINConv, SAGEConv
from torch_geometric.nn import global_mean_pool, global_add_pool

class GCN(torch.nn.Module):
    """GCN"""
    def __init__(self, num_entities, num_relations, num_bases, dropout):
        super(GCN, self).__init__()

        self.entity_embedding = torch.nn.Embedding(num_entities, 100)
        self.relation_embedding = torch.nn.Parameter(torch.Tensor(num_relations, 100))

        torch.nn.init.xavier_uniform_(self.relation_embedding, gain=torch.nn.init.calculate_gain('relu'))

        self.conv1 = GCNConv(100, 100)
        self.conv2 = GCNConv(100, 100)

        self.dropout_ratio = dropout


    def forward(self, entity, edge_index, edge_type, edge_norm):
        x = self.entity_embedding(entity)
        x = F.relu(self.conv1(x, edge_index))
        x = F.dropout(x, p = self.dropout_ratio, training = self.training)
        x = self.conv2(x, edge_index)
        return x
    
class GIN(torch.nn.Module):
    """GIN"""
    def __init__(self, num_entities, num_relations, num_bases, dropout):
        super(GIN, self).__init__()

        self.entity_embedding = torch.nn.Embedding(num_entities, 100)
        self.relation_embedding = torch.nn.Parameter(torch.Tensor(num_relations, 100))

        torch.nn.init.xavier_uniform_(self.relation_embedding, gain=torch.nn.init.calculate_gain('relu'))

        self.conv1 = GINConv(
            Sequential(Linear(100, 100),
                       BatchNorm1d(100), ReLU(),
                       Linear(100, 100), ReLU()))
        self.conv2 = GINConv(
            Sequential(Linear(100, 100), BatchNorm1d(100), ReLU(),
                       Linear(100, 100), ReLU()))
        
        #self.lin1 = Linear(100*3, 100*3)
        #self.lin2 = Linear(100*3, num_bases)
        
        self.dropout_ratio = dropout

    def forward(self, entity, edge_index, edge_type, edge_norm):
        x = self.entity_embedding(entity)
        x = F.relu(self.conv1(x, edge_index))
        x = F.dropout(x, p = self.dropout_ratio, training = self.training)
        x = self.conv2(x, edge_index)
        return x
    
class SAGE(torch.nn.Module):
    """SAGE"""
    def __init__(self, num_entities, num_relations, num_bases, dropout):
        super(SAGE, self).__init__()

        self.entity_embedding = torch.nn.Embedding(num_entities, 100)
        self.relation_embedding = torch.nn.Parameter(torch.Tensor(num_relations, 100))

        torch.nn.init.xavier_uniform_(self.relation_embedding, gain=torch.nn.init.calculate_gain('relu'))

        self.conv1 = SAGEConv(100, 100)
        self.conv2 = SAGEConv(100, 100)
        
        self.dropout_ratio = dropout

    def forward(self, entity, edge_index, edge_type, edge_norm):
        x = self.entity_embedding(entity)
        x = F.relu(self.conv1(x, edge_index))
        x = F.dropout(x, p = self.dropout_ratio, training = self.training)
        x = self.conv2(x, edge_index)
        return x