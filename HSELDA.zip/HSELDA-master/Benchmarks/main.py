import sys
import os
import torch
import random
import numpy as np
from tqdm import tqdm
from torch.autograd import Variable
from torch.nn.parameter import Parameter
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import math
import pdb
from models import RGCN
from Benchmarks import GCN, GIN, SAGE
from mlp_dropout import MLPClassifier, MLPRegression
from sklearn import metrics
from sklearn import neighbors
from util import cmd_args, load_data
from utils import edge_normalization
import scikitplot as skplt
import matplotlib.pyplot as plt

class Classifier(nn.Module):
    def __init__(self, regression=False):
        super(Classifier, self).__init__()
        self.regression = regression
        if cmd_args.gm == 'RGCN':
            model = RGCN
        elif cmd_args.gm == 'GCN':
            model = GCN
        elif cmd_args.gm == 'GIN':
            model = GIN
        elif cmd_args.gm == 'SAGE':
            model = SAGE
        else:
            print('unknown gm %s' % cmd_args.gm)
            sys.exit()


        if cmd_args.gm == 'RGCN' or cmd_args.gm == 'GCN' or cmd_args.gm == 'GIN' or cmd_args.gm == 'SAGE':
            self.gnn = model(num_entities = cmd_args.num_entities,
                            num_relations = cmd_args.num_relations,
                            num_bases = cmd_args.num_bases,
                            dropout = cmd_args.RGCN_dropout)
     
        out_dim = cmd_args.out_dim
        if out_dim == 0:
            if cmd_args.gm == 'RGCN' or cmd_args == 'GCN' or cmd_args == 'GIN' or cmd_args == SAGE:
                out_dim = 300
            else:
                out_dim = cmd_args.latent_dim
        self.mlp = MLPClassifier(input_size=out_dim, hidden_size=cmd_args.hidden, num_class=cmd_args.num_class, with_dropout=cmd_args.RGCN_dropout)
        if regression:
            self.mlp = MLPRegression(input_size=out_dim, hidden_size=cmd_args.hidden, with_dropout=cmd_args.RGCN_dropout)

    def PrepareFeatureLabel(self, batch_graph):
        if self.regression:
            labels = torch.FloatTensor(len(batch_graph))
        else:
            labels = torch.LongTensor(len(batch_graph))
        n_nodes = 0
        if batch_graph[0].node_tags is not None:
            node_tag_flag = True
            concat_tag = []
        else:
            node_tag_flag = False

        if batch_graph[0].node_features is not None:
            node_feat_flag = True
            concat_feat = []
        else:
            node_feat_flag = False

        if cmd_args.edge_feat_dim > 0:
            edge_feat_flag = True
            concat_edge_feat = []
        else:
            edge_feat_flag = False

        for i in range(len(batch_graph)):
            labels[i] = batch_graph[i].label
            n_nodes += batch_graph[i].num_nodes
            if node_tag_flag == True:
                concat_tag += batch_graph[i].node_tags
            if node_feat_flag == True:
                tmp = torch.from_numpy(batch_graph[i].node_features).type('torch.FloatTensor')
                concat_feat.append(tmp)
            if edge_feat_flag == True:
                if batch_graph[i].edge_features is not None:  # in case no edge in graph[i]
                    tmp = torch.from_numpy(batch_graph[i].edge_features).type('torch.FloatTensor')
                    concat_edge_feat.append(tmp)

        if node_tag_flag == True:
            concat_tag = torch.LongTensor(concat_tag).view(-1, 1)
            node_tag = torch.zeros(n_nodes, cmd_args.feat_dim)
            node_tag.scatter_(1, concat_tag, 1)

        if node_feat_flag == True:
            node_feat = torch.cat(concat_feat, 0)

        if node_feat_flag and node_tag_flag:
            # concatenate one-hot embedding of node tags (node labels) with continuous node features
            node_feat = torch.cat([node_tag.type_as(node_feat), node_feat], 1)
        elif node_feat_flag == False and node_tag_flag == True:
            node_feat = node_tag
        elif node_feat_flag == True and node_tag_flag == False:
            pass
        else:
            node_feat = torch.ones(n_nodes, 1)  # use all-one vector as node features
        
        if edge_feat_flag == True:
            edge_feat = torch.cat(concat_edge_feat, 0)

        if cmd_args.mode == 'gpu':
            node_feat = node_feat.cuda()
            labels = labels.cuda()
            if edge_feat_flag == True:
                edge_feat = edge_feat.cuda()

        if edge_feat_flag == True:
            return node_feat, edge_feat, labels
        return node_feat, labels

    def forward(self, batch_graph):

        feature_label = self.PrepareFeatureLabel(batch_graph)
        if len(feature_label) == 2:
            node_feat, labels = feature_label
            edge_feat = None
        elif len(feature_label) == 3:
            node_feat, edge_feat, labels = feature_label
        #embed = self.gnn(batch_graph, node_feat, edge_feat)

        embed_list = []

        for sub_graph in batch_graph:
            entity = sub_graph.node_list
            entity = torch.tensor(entity,dtype=torch.long).contiguous()

            first = []
            second = []
            for x in range(0, len(sub_graph.edge_pairs)):
                if x%2 == 0:
                    first.append(sub_graph.edge_pairs[x])
                else:
                    second.append(sub_graph.edge_pairs[x])
            first = torch.tensor(first,dtype=torch.long).contiguous()
            second = torch.tensor(second,dtype=torch.long).contiguous()
            edge_index = torch.stack((first,second))

            edge_type = []
            original = sub_graph.original_edges
            for i in range(len(original)):
                if (cmd_args.IncRNA_Min_Index<=original[i][0]<=cmd_args.IncRNA_Max_Index and cmd_args.Disease_Min_Index<=original[i][1]<=cmd_args.Disease_Max_Index) or (cmd_args.IncRNA_Min_Index<=original[i][1]<=cmd_args.IncRNA_Max_Index and cmd_args.Disease_Min_Index<=original[i][0]<=cmd_args.Disease_Max_Index) :
                    edge_type.insert(i, 1)
                elif (cmd_args.IncRNA_Min_Index<=original[i][0]<=cmd_args.IncRNA_Max_Index and cmd_args.MiRNA_Min_Index<=original[i][1]<=cmd_args.MiRNA_Max_Index) or (cmd_args.IncRNA_Min_Index<=original[i][1]<=cmd_args.IncRNA_Max_Index and cmd_args.MiRNA_Min_Index<=original[i][0]<=cmd_args.MiRNA_Max_Index):
                    edge_type.insert(i, 2)
                else:
                    edge_type.insert(i, 3)
            edge_type = torch.tensor(edge_type,dtype=torch.long).contiguous()

            edge_norm = edge_normalization(edge_type, edge_index, len(entity), 3)
            
            if cmd_args.mode == 'gpu':
                entity = entity.cuda()
                edge_index = edge_index.cuda()
                edge_type = edge_type.cuda()
                edge_norm = edge_norm.cuda()
            
            cur_embed = self.gnn(entity, edge_index, edge_type, edge_norm)
            cur_embed = readout(cur_embed)
            embed_list.append(cur_embed)
            embed = torch.stack(embed_list, 0)
        return self.mlp(embed, labels)

        def output_features(self, batch_graph):
            feature_label = self.PrepareFeatureLabel(batch_graph)
            if len(feature_label) == 2:
                node_feat, labels = feature_label
                edge_feat = None
            elif len(feature_label) == 3:
                node_feat, edge_feat, labels = feature_label
            embed = self.gnn(batch_graph, node_feat, edge_feat)
            return embed, labels

def readout(h):
        h_max = torch.max(h, 0)[0]
        h_sum = torch.sum(h, 0)
        h_mean = torch.mean(h, 0)
        add = [h_max, h_sum, h_mean]
        result = torch.cat(add)
        return result

def loop_dataset(g_list, classifier, sample_idxes, optimizer=None, bsize=cmd_args.batch_size):
    total_loss = []
    total_iters = (len(sample_idxes) + (bsize - 1) * (optimizer is None)) // bsize
    pbar = tqdm(range(total_iters), unit='batch')
    all_targets = []
    all_scores = []

    n_samples = 0
    for pos in pbar:
        selected_idx = sample_idxes[pos * bsize : (pos + 1) * bsize]

        batch_graph = [g_list[idx] for idx in selected_idx]
        targets = [g_list[idx].label for idx in selected_idx]
        #print(targets)
        all_targets += targets
        if classifier.regression:
            pred, mae, loss = classifier(batch_graph)
            all_scores.append(pred.cpu().detach())  # for binary classification
        else:
            logits, loss, acc = classifier(batch_graph)
            all_scores.append(logits[:, 1].cpu().detach())  # for binary classification

        if optimizer is not None:
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

        loss = loss.data.cpu().detach().numpy()
        if classifier.regression:
            pbar.set_description('MSE_loss: %0.5f MAE_loss: %0.5f' % (loss, mae) )
            total_loss.append( np.array([loss, mae]) * len(selected_idx))
        else:
            pbar.set_description('loss: %0.5f acc: %0.5f' % (loss, acc) )
            total_loss.append( np.array([loss, acc]) * len(selected_idx))


        n_samples += len(selected_idx)
    if optimizer is None:
        assert n_samples == len(sample_idxes)
    total_loss = np.array(total_loss)
    avg_loss = np.sum(total_loss, 0) / n_samples
    all_scores = torch.cat(all_scores).cpu().numpy()
    
    np.savetxt('test_scores.txt', all_scores)  # output test predictions
    
    if not classifier.regression and cmd_args.printAUC:
        all_targets = np.array(all_targets) #ground truth labels
        fpr, tpr, _ = metrics.roc_curve(all_targets, all_scores, pos_label=1)
        precision, recall, threshold = metrics.precision_recall_curve(all_targets, all_scores, pos_label=1)
        #fpr_2, fnr, _ = metrics.det_curve(all_targets, all_scores, pos_label=1)
        auc = metrics.auc(fpr, tpr)
        auprc = metrics.average_precision_score(all_targets, all_scores, pos_label=1)
        print('precision')
        print(np.average(precision))
        print('recall')
        print(np.average(recall))
        

        avg_loss = np.concatenate((avg_loss, [auc]))
        avg_loss = np.concatenate((avg_loss,[auprc]))
    else:
        avg_loss = np.concatenate((avg_loss, [0.0]))
        avg_loss = np.concatenate((avg_loss, [0.0]))
    
    metrics_lists = [fpr,tpr]
    return avg_loss, metrics_lists

