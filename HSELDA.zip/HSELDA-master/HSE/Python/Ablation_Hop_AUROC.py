from sklearn import metrics
import matplotlib.pyplot as plt

AUROC_1 = [0.96768, 0.96771, 0.96726, 0.96698, 0.96718, 0.96721, 0.96786, 0.96716, 0.96723, 0.96768]
AUROC_2 = [0.94701, 0.95231, 0.95424, 0.95039, 0.95293, 0.95301, 0.95337, 0.95258, 0.95294, 0.95205]
AUROC_3 = [0.89813, 0.91546, 0.89201, 0.90878, 0.89933, 0.91221, 0.90369, 0.90581, 0.89973, 0.89925]

Expeirmental_times = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

plt.plot(Expeirmental_times, AUROC_1, label = "Hop = 1", marker='o', markerfacecolor='black', markersize=5)
plt.plot(Expeirmental_times, AUROC_2, label = "Hop = 2", marker='o', markerfacecolor='black', markersize=5)
plt.plot(Expeirmental_times, AUROC_3, label = "Hop = 3", marker='o', markerfacecolor='black', markersize=5)
plt.ylabel('AUROC')
plt.xlabel('Experimental_Times')
plt.title("(a) AUROC with different Hop")
plt.legend(fontsize = 8.5)
plt.show()
plt.savefig('AUROC_Hop')



