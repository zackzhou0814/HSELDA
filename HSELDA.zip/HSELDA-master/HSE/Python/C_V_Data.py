import random
#generate cross-validation data
file = open('data/all_links.txt', 'r')
file_lines = file.readlines()
# file.close()
random.shuffle(file_lines)
open('data/links_shuffled.txt', 'w').writelines(file_lines)

count = 0
for line in file_lines:
    count += 1

num_of_test = int(count*0.2)

line_list_1 = [item for item in range(1, num_of_test+1)]
line_list_2 = [item for item in range(num_of_test+1, 2*num_of_test+1)]
line_list_3 = [item for item in range(2*num_of_test+1, 3*num_of_test+1)]
line_list_4 = [item for item in range(3*num_of_test+1, 4*num_of_test+1)]
line_list_5 = [item for item in range(4*num_of_test+1, 5*num_of_test+3)]

line_lists = [line_list_1,line_list_2,line_list_3,line_list_4,line_list_5]

count = 0
for line_list in line_lists:
    with open('data/IncRNA_DO_Testing_'+str(count+1)+'.txt', 'w') as f:
        for line in line_list:
            f.write(file_lines[line-1])

    for i in range(len(line_list)):
        line_list[i] = line_list[i]-1

    with open('data/IncRNA_DO_Pos_Train_'+str(count+1)+'.txt', 'w') as original_f:
        for number, line in enumerate(file_lines):
            if number not in line_list:
                original_f.write(line)
    count+=1