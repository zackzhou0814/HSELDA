import numpy as np
from scipy.io import savemat

num_nodes = 1147
num_features = 3

node_matrix = np.ndarray(shape=(num_nodes, num_features), dtype=float)

for i in range(240):
    node_matrix[i][0] = 1
    node_matrix[i][1] = 0
    node_matrix[i][2] = 0

for i in range(240, 652):
    node_matrix[i][0] = 0
    node_matrix[i][1] = 1
    node_matrix[i][2] = 0

for i in range(652, 1147):
    node_matrix[i][0] = 0
    node_matrix[i][1] = 0
    node_matrix[i][2] = 1

mdic = {"matrix": node_matrix}

savemat("group.mat", mdic)
