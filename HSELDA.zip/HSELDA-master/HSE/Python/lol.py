list = [1,2,3,4,5]
sub_list = [1,2,3]
start = sub_list[0]
print(start)
end = sub_list[-1]
print(end)
del list[start-1: end]
print(list)