python Main.py --train-name IncRNA_DO_Pos_Train_1.txt --test-name IncRNA_DO_Testing_1.txt --hop 1 --use-embedding
python Main.py --train-name IncRNA_DO_Pos_Train_2.txt --test-name IncRNA_DO_Testing_2.txt --hop 1 --use-embedding
python Main.py --train-name IncRNA_DO_Pos_Train_3.txt --test-name IncRNA_DO_Testing_3.txt --hop 1 --use-embedding
python Main.py --train-name IncRNA_DO_Pos_Train_4.txt --test-name IncRNA_DO_Testing_4.txt --hop 1 --use-embedding
python Main.py --train-name IncRNA_DO_Pos_Train_5.txt --test-name IncRNA_DO_Testing_5.txt --hop 1 --use-embedding
