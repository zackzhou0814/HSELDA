from sklearn import metrics
import matplotlib.pyplot as plt

AUPR_0 = [0.94853, 0.95710, 0.94851, 0.94672, 0.94827, 0.94579, 0.95405, 0.94567, 0.94012, 0.94001]
AUPR_1 = [0.96806, 0.96797, 0.96711, 0.96710, 0.96722, 0.96706, 0.96806, 0.96729, 0.96754, 0.96736]
AUPR_2 = [0.96516, 0.96478, 0.96433, 0.96301, 0.96393, 0.96413, 0.96480, 0.96551, 0.96337, 0.96341]
AUPR_3 = [0.96378, 0.96346, 0.96618, 0.96349, 0.96401, 0.96242, 0.96625, 0.96481, 0.96718, 0.96668]
AUPR_4 = [0.96557, 0.96284, 0.95773, 0.96138, 0.95712, 0.95927, 0.96278, 0.96111, 0.95892, 0.96915]
AUPR_5 = [0.93767, 0.94158, 0.95387, 0.93966, 0.95406, 0.94708, 0.94713, 0.94950, 0.93883, 0.93277]
AUPR_6 = [0.81566, 0.70276, 0.79548, 0.74913, 0.75017, 0.69374, 0.73569, 0.70024, 0.62708, 0.66474]

Expeirmental_times = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

plt.plot(Expeirmental_times, AUPR_0, label = "Learning Rate = 0.00001", marker='o', markerfacecolor='black', markersize=5)
plt.plot(Expeirmental_times, AUPR_1, label = "Learning Rate = 0.0001", marker='o', markerfacecolor='black', markersize=5)
plt.plot(Expeirmental_times, AUPR_2, label = "Learning Rate = 0.0005", marker='o', markerfacecolor='black', markersize=5)
plt.plot(Expeirmental_times, AUPR_3, label = "Learning Rate = 0.001", marker='o', markerfacecolor='black', markersize=5)
plt.plot(Expeirmental_times, AUPR_4, label = "Learning Rate = 0.005", marker='o', markerfacecolor='black', markersize=5)
plt.plot(Expeirmental_times, AUPR_5, label = "Learning Rate = 0.01", marker='o', markerfacecolor='black', markersize=5)
plt.plot(Expeirmental_times, AUPR_6, label = "Learning Rate = 0.1", marker='o', markerfacecolor='black', markersize=5)
plt.ylabel('AUPR')
plt.xlabel('Experimental_Times')
plt.title("(b) AUPR with different learning rate")
plt.legend(fontsize = 8.5)
plt.show()
plt.savefig('AUPR_LR')



