from sklearn import metrics
import matplotlib.pyplot as plt

AUROC_0 = [0.94419, 0.95331, 0.94426, 0.94321, 0.94682, 0.94235, 0.94251, 0.95023, 0.94821, 0.93872]
AUROC_1 = [0.96798, 0.96771, 0.96726, 0.96698, 0.96718, 0.96721, 0.96786, 0.96716, 0.96723, 0.96768]
AUROC_2 = [0.96554, 0.96857, 0.96667, 0.96574, 0.96625, 0.96580, 0.96478, 0.96670, 0.96590, 0.96664]
AUROC_3 = [0.96471, 0.96389, 0.96660, 0.96627, 0.96459, 0.96415, 0.96631, 0.96479, 0.96750, 0.96578]
AUROC_4 = [0.96500, 0.96329, 0.95959, 0.96384, 0.95690, 0.96207, 0.96172,0.96501, 0.96312, 0.96412]
AUROC_5 = [0.93696, 0.94065, 0.95374, 0.94578, 0.95391, 0.94648, 0.94924, 0.95226, 0.93738, 0.95271]
AUROC_6 = [0.79175, 0.76323, 0.77906, 0.76096, 0.76202, 0.72867, 0.73154, 0.70321, 0.68802, 0.68174]

Expeirmental_times = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

plt.plot(Expeirmental_times, AUROC_0, label = "Learning Rate = 0.00001", marker='o', markerfacecolor='black', markersize=5)
plt.plot(Expeirmental_times, AUROC_1, label = "Learning Rate = 0.0001", marker='o', markerfacecolor='black', markersize=5)
plt.plot(Expeirmental_times, AUROC_2, label = "Learning Rate = 0.0005", marker='o', markerfacecolor='black', markersize=5)
plt.plot(Expeirmental_times, AUROC_3, label = "Learning Rate = 0.001", marker='o', markerfacecolor='black', markersize=5)
plt.plot(Expeirmental_times, AUROC_4, label = "Learning Rate = 0.005", marker='o', markerfacecolor='black', markersize=5)
plt.plot(Expeirmental_times, AUROC_5, label = "Learning Rate = 0.01", marker='o', markerfacecolor='black', markersize=5)
plt.plot(Expeirmental_times, AUROC_6, label = "Learning Rate = 0.1", marker='o', markerfacecolor='black', markersize=5)
plt.ylabel('AUROC')
plt.xlabel('Experimental_Times')
plt.title("(a) AUROC with different learning rate")
plt.legend(fontsize = 8.5)
plt.show()
plt.savefig('AUROC_LR')



