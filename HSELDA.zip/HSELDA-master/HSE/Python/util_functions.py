from __future__ import print_function
import numpy as np
import random
from tqdm import tqdm
import os, sys, pdb, math, time
import networkx as nx
import argparse
import scipy.io as sio
import scipy.sparse as ssp
from sklearn import metrics
from gensim.models import Word2Vec
import warnings
warnings.simplefilter('ignore', ssp.SparseEfficiencyWarning)
cur_dir = os.path.dirname(os.path.realpath(__file__))
sys.path.append('%s/../../pytorch_Benchmarks' % cur_dir)
sys.path.append('%s/software/node2vec/src' % cur_dir)
from util import GNNGraph, cmd_args
import node2vec
import multiprocessing as mp
from itertools import islice

def sample_neg(net, test_ratio=0.1, train_pos=None, test_pos=None, max_train_num=None,
               all_unknown_as_negative=False):
    # get upper triangular matrix
    net_triu = ssp.triu(net, k=1)
    # sample positive links for train/test
    row, col, _ = ssp.find(net_triu)
    # sample positive links if not specified
    if train_pos is None and test_pos is None:
        perm = random.sample(range(len(row)), len(row))
        row, col = row[perm], col[perm]
        split = int(math.ceil(len(row) * (1 - test_ratio)))
        train_pos = (row[:split], col[:split])
        test_pos = (row[split:], col[split:])
    
    # sample negative links for train/test 
    if max_train_num is not None and train_pos is not None:        
        perm = np.random.permutation(len(train_pos[0]))[:max_train_num]
        #perm = np.random.permutation(len(train_pos_filter_final[0]))[:max_train_num]
        train_pos = (train_pos[0][perm], train_pos[1][perm])
        #train_pos_filter_final = (train_pos_filter_final[0][perm], train_pos_filter_final[1][perm])

    #sample negative links for train/test
    train_num = len(train_pos[0]) if train_pos else 0
    test_num = len(test_pos[0]) if test_pos else 0

    i_d_train_count = 0
    i_m_train_count = 0
    m_d_train_count = 0
    for i in range(len(train_pos[0])):
        if (cmd_args.IncRNA_Min_Index<= train_pos[0][i] <=cmd_args.IncRNA_Max_Index and cmd_args.Disease_Min_Index<= train_pos[1][i] <=cmd_args.Disease_Max_Index) or (cmd_args.IncRNA_Min_Index<= train_pos[1][i] <=cmd_args.IncRNA_Max_Index and cmd_args.Disease_Min_Index<= train_pos[0][i] <=cmd_args.Disease_Max_Index):
            i_d_train_count+=1
        elif (cmd_args.IncRNA_Min_Index<= train_pos[0][i] <=cmd_args.IncRNA_Max_Index and cmd_args.MiRNA_Min_Index<= train_pos[1][i] <=cmd_args.MiRNA_Max_Index) or (cmd_args.IncRNA_Min_Index<= train_pos[1][i] <=cmd_args.IncRNA_Max_Index and cmd_args.MiRNA_Min_Index<= train_pos[0][i] <=cmd_args.MiRNA_Max_Index):
            i_m_train_count+=1
        else:
            m_d_train_count+=1
    
    i_d_test_count = 0
    i_m_test_count = 0
    m_d_test_count = 0
    for i in range(len(test_pos[0])):
        if (cmd_args.IncRNA_Min_Index<= test_pos[0][i] <=cmd_args.IncRNA_Max_Index and cmd_args.Disease_Min_Index<= test_pos[1][i] <=cmd_args.Disease_Max_Index) or (cmd_args.IncRNA_Min_Index<= test_pos[1][i] <=cmd_args.IncRNA_Max_Index and cmd_args.Disease_Min_Index<= test_pos[0][i] <=cmd_args.Disease_Max_Index):
            i_d_test_count+=1
        elif (cmd_args.IncRNA_Min_Index<= test_pos[0][i] <=cmd_args.IncRNA_Max_Index and cmd_args.MiRNA_Min_Index<= test_pos[1][i] <=cmd_args.MiRNA_Max_Index) or (cmd_args.IncRNA_Min_Index<= test_pos[1][i] <=cmd_args.IncRNA_Max_Index and cmd_args.MiRNA_Min_Index<= test_pos[0][i] <=cmd_args.MiRNA_Max_Index):
            i_m_test_count+=1
        else:
            m_d_test_count+=1

    test_pos_filter = ([], [])
    test_neg_filter = ([], [])
    test_pos_filter_extra = ([], [])
    test_neg_filter_extra = ([], [])
  
    neg = ([], [])
    i_d_train = ([], [])
    i_m_train = ([], [])
    d_m_train = ([], [])
    i_d_test = ([], [])
    i_m_test = ([], [])
    d_m_test = ([], [])


    #neg_filter = ([], [])
    n = net.shape[0]
    print('sampling negative links for train and test')
    if not all_unknown_as_negative:
        while len(neg[0]) < train_num + test_num:
            i, j = random.randint(0, n-1), random.randint(0, n-1)
            if i < j and net[i, j] == 0:
                neg[0].append(i)
                neg[1].append(j)
            else:
                continue
        train_neg = (neg[0][:train_num], neg[1][:train_num])
        test_neg = (neg[0][train_num:], neg[1][train_num:])

    else:
        # regard all unknown links as test_negs, sample a portion from them as train_negs
        while len(neg[0]) < train_num:
            i, j = random.randint(0, n-1), random.randint(0, n-1)
            if i < j and net[i, j] == 0:
                neg[0].append(i)
                neg[1].append(j)
            else:
                continue
        train_neg  = (neg[0], neg[1])
        test_neg_i, test_neg_j, _ = ssp.find(ssp.triu(net==0, k=1))
        test_neg = (test_neg_i.tolist(), test_neg_j.tolist())
    do_index = 384
    # 247 249 305 306 357 384 400 455 477 581

    # for i in range(len(test_pos[0])):
    #     x = test_pos[0][i]
    #     y = test_pos[1][i]
    #     if (x == do_index and cmd_args.IncRNA_Min_Index<=y<=cmd_args.IncRNA_Max_Index) or (y == do_index and cmd_args.IncRNA_Min_Index<=x<=cmd_args.IncRNA_Max_Index):
    #         test_pos_filter[0].append(x)
    #         test_pos_filter[1].append(y)

    # for j in range(cmd_args.IncRNA_Min_Index, 120):
    #     if (j not in test_pos_filter[0]) and (j not in test_pos_filter[1]):
    #         test_neg_filter[0].append(j)
    #         test_neg_filter[1].append(do_index)

    # for j in range(120, cmd_args.IncRNA_Max_Index+1):
    #     if (j not in test_pos_filter[0]) and (j not in test_pos_filter[1]):
    #         train_neg[0].append(j)
    #         train_neg[1].append(do_index)

    return train_pos, train_neg, test_pos, test_neg

    
def links2subgraphs(A, train_pos, train_neg, test_pos, test_neg, h=1, 
                    max_nodes_per_hop=None, node_information=None, no_parallel=False):
    # automatically select h from {1, 2}
    if h == 'auto':
        # split train into val_train and val_test
        _, _, val_test_pos, val_test_neg = sample_neg(A, 0.1)
        val_A = A.copy()
        val_A[val_test_pos[0], val_test_pos[1]] = 0
        val_A[val_test_pos[1], val_test_pos[0]] = 0
        val_auc_CN = CN(val_A, val_test_pos, val_test_neg)
        val_auc_AA = AA(val_A, val_test_pos, val_test_neg)
        print('\033[91mValidation AUC of AA is {}, CN is {}\033[0m'.format(
            val_auc_AA, val_auc_CN))
        if val_auc_AA >= val_auc_CN:
            h = 2
            print('\033[91mChoose h=2\033[0m')
        else:
            h = 1
            print('\033[91mChoose h=1\033[0m')

    # extract enclosing subgraphs
    max_n_label = {'value': 0}
    g_list = []
    def helper(A, links, g_label):
        if no_parallel:
            for i, j in tqdm(zip(links[0], links[1])):
                g, n_labels, n_features, node_list = subgraph_extraction_labeling(
                    (i, j), A, h, max_nodes_per_hop, node_information
                )
                max_n_label['value'] = max(max(n_labels), max_n_label['value'])
                g_list.append(GNNGraph(g, g_label, n_labels, n_features, node_list))
            return g_list
        else:
            # the parallel extraction code
            start = time.time()
            pool = mp.Pool(mp.cpu_count())
            results = pool.map_async(
                parallel_worker, 
                [((i, j), A, h, max_nodes_per_hop, node_information) for i, j in zip(links[0], links[1])]
            )
            remaining = results._number_left
            pbar = tqdm(total=remaining)
            while True:
                pbar.update(remaining - results._number_left)
                if results.ready(): break
                remaining = results._number_left
                time.sleep(1)
            results = results.get()
            pool.close()
            pbar.close()
            g_list = [GNNGraph(g, g_label, n_labels, n_features, node_list) for g, n_labels, n_features, node_list in results]
            max_n_label['value'] = max(
                max([max(n_labels) for _, n_labels, _, _ in results]), max_n_label['value']
            )

            end = time.time()
            print("Time eplased for subgraph extraction: {}s".format(end-start))
            return g_list


    print('Enclosing subgraph extraction begins...')
    train_graphs, test_graphs = None, None

    if train_pos and train_neg:
        train_graphs = helper(A, train_pos, 1) + helper(A, train_neg, 0)
    if test_pos and test_neg:
        test_graphs = helper(A, test_pos, 1) + helper(A, test_neg, 0)
    elif test_pos:
        test_graphs = helper(A, test_pos, 1)

    #print(train_graphs[10000].nodes)
    #print(train_graphs[7219].node_list)
    # print(train_graphs[5000].node_hash)
    #print(train_graphs[7219].edges)
    #print(train_graphs[7219].original_edges)
    # original = train_graphs[5000].original_edges
    # edge_index = []
    # for i in range(len(original)):
    #     if (1<=original[i][0]<=240 and 241<=original[i][1]<=652) or (1<=original[i][1]<=240 and 241<=original[i][0]<=652) :
    #         edge_index.insert(i, 1)
    #     elif (1<=original[i][0]<=240 and 653<=original[i][1]<=1147) or (1<=original[i][1]<=240 and 653<=original[i][0]<=1147):
    #         edge_index.insert(i, 2)
    #     else:
    #         edge_index.insert(i, 3)
    #print(edge_index) 


    #train_pos_filter = ([], [])
    # train_pos_filter_final = ()
    # for i in range(len(train_pos[0])):
    #     x = train_pos[0][i]
    #     y = train_pos[1][i]
    #     if (cmd_args.IncRNA_Min_Index<= x <=cmd_args.IncRNA_Max_Index and cmd_args.Disease_Min_Index<= y <=cmd_args.Disease_Max_Index) or (cmd_args.IncRNA_Min_Index<= y <=cmd_args.IncRNA_Max_Index and cmd_args.Disease_Min_Index<= x <=cmd_args.Disease_Max_Index):
    #         train_pos_filter[0].append(x)
    #         train_pos_filter[1].append(y)
    
    
    # test_pos_filter = ([], [])
    # # train_pos_filter_final = ()
    # for i in range(len(test_pos[0])):
    #     x = test_pos[0][i]
    #     y = test_pos[1][i]
    #     if (cmd_args.IncRNA_Min_Index<= x <=cmd_args.IncRNA_Max_Index and cmd_args.Disease_Min_Index<= y <=cmd_args.Disease_Max_Index) or (cmd_args.IncRNA_Min_Index<= y <=cmd_args.IncRNA_Max_Index and cmd_args.Disease_Min_Index<= x <=cmd_args.Disease_Max_Index):
    #         test_pos_filter[0].append(x)
    #         test_pos_filter[1].append(y)

    train_graphs_modify = []
    test_graphs_modify =[]
    extra_train = ([], [])
    extra_test = ([], [])
    train_extra_id = []
    train_extra_ii_dd = []
    test_extra_id = []
    test_extra_ii_dd = []
    extra_train_id = ([], [])
    extra_test_id = ([], [])
    extra_train_ii_dd = ([], [])
    extra_test_ii_dd = ([], [])
    extra_test = ([], [])
    n = A.shape[0]
    for graph in train_graphs:
        if (cmd_args.IncRNA_Min_Index<=graph.node_list[0]<=cmd_args.IncRNA_Max_Index and cmd_args.Disease_Min_Index<=graph.node_list[1]<=cmd_args.Disease_Max_Index) or (cmd_args.IncRNA_Min_Index<=graph.node_list[1]<=cmd_args.IncRNA_Max_Index and cmd_args.Disease_Min_Index<=graph.node_list[0]<=cmd_args.Disease_Max_Index): 
            train_graphs_modify.append(graph)

    #1
    do_index = 247
    train_len = len(train_graphs_modify)
    num_add_train = 4315-train_len
    # num_add_id_train = int(num_add_train*0.45)
    # num_add_ii_dd_train = int(num_add_train*0.55)
    # print(num_add_id_train)


    # while len(extra_train[0])<=num_add_train:
    #     i, j = random.randint(0, n-1), random.randint(0, n-1)
    #     if((cmd_args.IncRNA_Min_Index<=i<=cmd_args.IncRNA_Max_Index and j==do_index) or (cmd_args.IncRNA_Min_Index<=j<=cmd_args.IncRNA_Max_Index and i==do_index)) and (A[i, j] == 0 or A[j, i] == 0):
    #         extra_train[0].append(i)
    #         extra_train[1].append(j)
    #     else:
    #         continue

    # train_extra = (extra_train[0], extra_train[1])
    # extra_train_graphs = helper(A, train_extra, 0)
    # train_graphs_modify = train_graphs_modify+extra_train_graphs
    # do_index = 357
    for graph in train_graphs:
        if(cmd_args.IncRNA_Min_Index<=graph.node_list[0]<=cmd_args.IncRNA_Max_Index and cmd_args.IncRNA_Min_Index<=graph.node_list[1]<=cmd_args.IncRNA_Max_Index) or (cmd_args.Disease_Min_Index<=graph.node_list[1]<=cmd_args.Disease_Max_Index and cmd_args.Disease_Min_Index<=graph.node_list[0]<=cmd_args.Disease_Max_Index):
            #cmd_args.IncRNA_Min_Index<=graph.node_list[0]<=cmd_args.IncRNA_Max_Index and graph.node_list[1]==do_index) or (cmd_args.IncRNA_Min_Index<=graph.node_list[1]<=cmd_args.IncRNA_Max_Index and graph.node_list[0]==do_index
                train_extra_ii_dd.append(graph)
    extra_train_data = train_extra_ii_dd[0:num_add_train]
    train_graphs_modify = train_graphs_modify+extra_train_data

    # train_len = len(train_graphs_modify)
    # num_add_train = 3815-train_len
    # while len(extra_train[0])<=num_add_train:
    #     i, j = random.randint(0, n-1), random.randint(0, n-1)
    #     if((cmd_args.IncRNA_Min_Index<=i<=cmd_args.IncRNA_Max_Index and cmd_args.Disease_Min_Index<=j<=cmd_args.Disease_Max_Index) or (cmd_args.IncRNA_Min_Index<=j<=cmd_args.IncRNA_Max_Index and cmd_args.Disease_Min_Index<=i<=cmd_args.Disease_Max_Index)) and (A[i, j] == 0 or A[j, i] == 0):
    #         extra_train[0].append(i)
    #         extra_train[1].append(j)
    #     else:
    #         continue

    # train_extra = (extra_train[0], extra_train[1])
    # extra_train_graphs = helper(A, train_extra, 0)
    # train_graphs_modify = train_graphs_modify+extra_train_graphs

    #2
    # train_len = len(train_graphs_modify)
    # num_add_train = 4315-train_len

    # for graph in train_graphs:
    #     if(cmd_args.IncRNA_Min_Index<=graph.node_list[0]<=cmd_args.IncRNA_Max_Index and cmd_args.IncRNA_Min_Index<=graph.node_list[1]<=cmd_args.IncRNA_Max_Index) or (cmd_args.Disease_Min_Index<=graph.node_list[1]<=cmd_args.Disease_Max_Index and cmd_args.Disease_Min_Index<=graph.node_list[0]<=cmd_args.Disease_Max_Index):
    #             train_extra.append(graph)
    # extra_train_data = train_extra[0:num_add_train+1]

    # train_graphs_modify = train_graphs_modify+extra_train_data


    for graph in test_graphs:
        if (cmd_args.IncRNA_Min_Index<=graph.node_list[0]<=cmd_args.IncRNA_Max_Index and cmd_args.Disease_Min_Index<=graph.node_list[1]<=cmd_args.Disease_Max_Index) or (cmd_args.IncRNA_Min_Index<=graph.node_list[1]<=cmd_args.IncRNA_Max_Index and cmd_args.Disease_Min_Index<=graph.node_list[0]<=cmd_args.Disease_Max_Index):
            test_graphs_modify.append(graph)
    
    #1
    test_len = len(test_graphs_modify)
    num_add_test = 1078-test_len
    # num_add_id_test = int(num_add_test*0.45)
    # num_add_ii_dd_test = int(num_add_test*0.55)
    # while len(extra_test[0])<=num_add_id_test:
    #     i, j = random.randint(0, n-1), random.randint(0, n-1)
    #     if((cmd_args.IncRNA_Min_Index<=i<=cmd_args.IncRNA_Max_Index and cmd_args.Disease_Min_Index<=j<=cmd_args.Disease_Max_Index) or (cmd_args.IncRNA_Min_Index<=j<=cmd_args.IncRNA_Max_Index and cmd_args.Disease_Min_Index<=i<=cmd_args.Disease_Max_Index)) and (A[i, j] == 0 or A[j, i] == 0):
    #         extra_test[0].append(i)
    #         extra_test[1].append(j)
    #     else:
    #         continue

    # test_extra = (extra_test[0], extra_test[1])
    # extra_test_graphs = helper(A, test_extra, 0)
    # test_graphs_modify = test_graphs_modify+extra_test_graphs

    for graph in test_graphs:
        if(cmd_args.IncRNA_Min_Index<=graph.node_list[0]<=cmd_args.IncRNA_Max_Index and cmd_args.IncRNA_Min_Index<=graph.node_list[1]<=cmd_args.IncRNA_Max_Index) or (cmd_args.Disease_Min_Index<=graph.node_list[1]<=cmd_args.Disease_Max_Index and cmd_args.Disease_Min_Index<=graph.node_list[0]<=cmd_args.Disease_Max_Index):
                test_extra_ii_dd.append(graph)
    extra_test_data = test_extra_ii_dd[0:num_add_test]
    test_graphs_modify = test_graphs_modify+extra_test_data
    
    #2
    # test_len = len(test_graphs_modify)
    # num_add_test = 1078-test_len
    # test_len = len(test_graphs_modify)
    # num_add_test = 1078-test_len
    # for graph in test_graphs:
    #              if(cmd_args.IncRNA_Min_Index<=graph.node_list[0]<=cmd_args.IncRNA_Max_Index and cmd_args.IncRNA_Min_Index<=graph.node_list[1]<=cmd_args.IncRNA_Max_Index) or (cmd_args.Disease_Min_Index<=graph.node_list[1]<=cmd_args.Disease_Max_Index and cmd_args.Disease_Min_Index<=graph.node_list[0]<=cmd_args.Disease_Max_Index):
    #                  test_extra.append(graph)
    # extra_test_data = test_extra[0:num_add_test+1]

    # test_graphs_modify = test_graphs_modify+extra_test_data
    
    # train_len = len(train_graphs_modify)
    # test_len = len(test_graphs_modify)
    # num_add_train = 4315-train_len
    # num_add_test = 1078-test_len

    # num_add_id_train = num_add_train*0.5
    # num_add_ii_dd_train = num_add_train*0.5
    
    # while len(extra_train_id[0])<=num_add_id_train:
    #     i, j = random.randint(0, n-1), random.randint(0, n-1)
    #     if((cmd_args.IncRNA_Min_Index<=i<=cmd_args.IncRNA_Max_Index and cmd_args.Disease_Min_Index<=j<=cmd_args.Disease_Max_Index) or (cmd_args.IncRNA_Min_Index<=j<=cmd_args.IncRNA_Max_Index and cmd_args.Disease_Min_Index<=i<=cmd_args.Disease_Max_Index)) and (A[i, j] == 0 or A[j, i] == 0):
    #         extra_train_id[0].append(i)
    #         extra_train_id[1].append(j)
    # train_extra_id = (extra_train_id[0], extra_train_id[1])
    # extra_train_graphs_id = helper(A, train_extra_id, 0)
    # train_graphs_modify = train_graphs_modify+extra_train_graphs_id

    # while len(extra_train_ii_dd[0])<=num_add_ii_dd_train:
    #     i, j = random.randint(0, n-1), random.randint(0, n-1)
    #     if(cmd_args.IncRNA_Min_Index<=graph.node_list[0]<=cmd_args.IncRNA_Max_Index and cmd_args.IncRNA_Min_Index<=graph.node_list[1]<=cmd_args.IncRNA_Max_Index) or (cmd_args.Disease_Min_Index<=graph.node_list[1]<=cmd_args.Disease_Max_Index and cmd_args.Disease_Min_Index<=graph.node_list[0]<=cmd_args.Disease_Max_Index):
    #         extra_train_ii_dd[0].append(i)
    #         extra_train_ii_dd[1].append(j)
    # train_extra_ii_dd = (extra_train_ii_dd[0], extra_train_ii_dd[1])
    # extra_train_graphs_ii_dd = helper(A, train_extra_ii_dd, 0)
    # train_graphs_modify = train_graphs_modify+extra_train_graphs_ii_dd


    # num_add_id_test = num_add_test*0.5
    # num_add_ii_dd_test = num_add_test*0.5

    # while len(extra_test_id[0])<=num_add_id_test:
    #     i, j = random.randint(0, n-1), random.randint(0, n-1)
    #     if((cmd_args.IncRNA_Min_Index<=i<=cmd_args.IncRNA_Max_Index and cmd_args.Disease_Min_Index<=j<=cmd_args.Disease_Max_Index) or (cmd_args.IncRNA_Min_Index<=j<=cmd_args.IncRNA_Max_Index and cmd_args.Disease_Min_Index<=i<=cmd_args.Disease_Max_Index)) and (A[i, j] == 0 or A[j, i] == 0):
    #         extra_test_id[0].append(i)
    #         extra_test_id[1].append(j)
    # test_extra_id = (extra_test_id[0], extra_test_id[1])
    # extra_test_graphs_id = helper(A, test_extra_id, 0)
    # test_graphs_modify = test_graphs_modify+extra_test_graphs_id

    # while len(extra_test_ii_dd[0])<=num_add_ii_dd_test:
    #     i, j = random.randint(0, n-1), random.randint(0, n-1)
    #     if(cmd_args.IncRNA_Min_Index<=graph.node_list[0]<=cmd_args.IncRNA_Max_Index and cmd_args.IncRNA_Min_Index<=graph.node_list[1]<=cmd_args.IncRNA_Max_Index) or (cmd_args.Disease_Min_Index<=graph.node_list[1]<=cmd_args.Disease_Max_Index and cmd_args.Disease_Min_Index<=graph.node_list[0]<=cmd_args.Disease_Max_Index):
    #         extra_test_ii_dd[0].append(i)
    #         extra_test_ii_dd[1].append(j)
    # test_extra_ii_dd = (extra_test_ii_dd[0], extra_test_ii_dd[1])
    # extra_test_graphs_ii_dd = helper(A, test_extra_ii_dd, 0)
    # test_graphs_modify = test_graphs_modify+extra_test_graphs_ii_dd




    # while len(extra_data[0])<=num_add_train+num_add_test:
    #     i, j = random.randint(0, n-1), random.randint(0, n-1)
    #     if((cmd_args.IncRNA_Min_Index<=i<=cmd_args.IncRNA_Max_Index and cmd_args.Disease_Min_Index<=j<=cmd_args.Disease_Max_Index) or (cmd_args.IncRNA_Min_Index<=j<=cmd_args.IncRNA_Max_Index and cmd_args.Disease_Min_Index<=i<=cmd_args.Disease_Max_Index)) and (A[i, j] == 0 or A[j, i] == 0):
    #     #if A[i, j] == 0 or A[j, i] == 0:
    #         extra_data[0].append(i)
    #         extra_data[1].append(j)

    # #the_extra = (extra_data[0], extra_data[1])
    # train_extra = (extra_data[0][:num_add_train+1], extra_data[1][:num_add_train+1])
    # test_extra = (extra_data[0][num_add_train+1:], extra_data[1][num_add_train+1:])
    # extra_train_graphs = helper(A, train_extra, 0)
    # extra_test_graphs = helper(A, test_extra, 0)
    # train_graphs_modify = train_graphs_modify+extra_train_graphs
    # test_graphs_modify = test_graphs_modify+extra_test_graphs


    # 247 249 305 306 357 384 400 455 477 581
    # for graph in test_graphs:
    #     if (cmd_args.IncRNA_Min_Index<=graph.node_list[0]<=cmd_args.IncRNA_Max_Index and graph.node_list[1]==do_index) or (cmd_args.IncRNA_Min_Index<=graph.node_list[1]<=cmd_args.IncRNA_Max_Index and graph.node_list[0]==do_index):
    #         test_graphs_modify.append(graph)

    return train_graphs_modify, test_graphs_modify, max_n_label['value']

def parallel_worker(x):
    return subgraph_extraction_labeling(*x)

def subgraph_extraction_labeling(ind, A, h=1, max_nodes_per_hop=None,
                                 node_information=None):
    # extract the h-hop enclosing subgraph around link 'ind'
    dist = 0
    nodes = set([ind[0], ind[1]])
    visited = set([ind[0], ind[1]])
    fringe = set([ind[0], ind[1]])
    nodes_dist = [0, 0]
    for dist in range(1, h+1):
        fringe = neighbors(fringe, A)
        fringe = fringe - visited
        visited = visited.union(fringe)
        if max_nodes_per_hop is not None:
            if max_nodes_per_hop < len(fringe):
                fringe = random.sample(fringe, max_nodes_per_hop)
        if len(fringe) == 0:
            break
        nodes = nodes.union(fringe)
        nodes_dist += [dist] * len(fringe)
    # move target nodes to top
    nodes.remove(ind[0])
    nodes.remove(ind[1])
    nodes = [ind[0], ind[1]] + list(nodes)
    #pdb.set_trace() 
    subgraph = A[nodes, :][:, nodes]
    # apply node-labeling
    labels = node_label(subgraph)
    # get node features
    features = None
    if node_information is not None:
        features = node_information[nodes]
    # construct nx graph
    g = nx.from_scipy_sparse_matrix(subgraph)
    # remove link between target nodes

    # if g.has_edge(0, 1):
    #     g.remove_edge(0, 1)
    return g, labels.tolist(), features, nodes


def neighbors(fringe, A):
    # find all 1-hop neighbors of nodes in fringe from A
    res = set()
    for node in fringe:
        nei, _, _ = ssp.find(A[:, node])
        nei = set(nei)
        res = res.union(nei)
    return res


def node_label(subgraph):
    # an implementation of the proposed double-radius node labeling (DRNL)
    K = subgraph.shape[0]
    subgraph_wo0 = subgraph[1:, 1:]
    subgraph_wo1 = subgraph[[0]+list(range(2, K)), :][:, [0]+list(range(2, K))]
    dist_to_0 = ssp.csgraph.shortest_path(subgraph_wo0, directed=False, unweighted=True)
    dist_to_0 = dist_to_0[1:, 0]
    dist_to_1 = ssp.csgraph.shortest_path(subgraph_wo1, directed=False, unweighted=True)
    dist_to_1 = dist_to_1[1:, 0]
    d = (dist_to_0 + dist_to_1).astype(np.int)
    d_over_2, d_mod_2 = np.divmod(d, 2)
    labels = 1 + np.minimum(dist_to_0, dist_to_1).astype(int) + d_over_2 * (d_over_2 + d_mod_2 - 1)
    labels = np.concatenate((np.array([1, 1]), labels))
    labels[np.isinf(labels)] = 0
    labels[labels>1e6] = 0  # set inf labels to 0
    labels[labels<-1e6] = 0  # set -inf labels to 0
    return labels

    
def generate_node2vec_embeddings(A, emd_size=128, negative_injection=False, train_neg=None):
    if negative_injection:
        row, col = train_neg
        A = A.copy()
        A[row, col] = 1  # inject negative train
        A[col, row] = 1  # inject negative train
    nx_G = nx.from_scipy_sparse_matrix(A)
    G = node2vec.Graph(nx_G, is_directed=False, p=1, q=1)
    G.preprocess_transition_probs()
    walks = G.simulate_walks(num_walks=10, walk_length=80)
    walks = [list(map(str, walk)) for walk in walks]
    model = Word2Vec(walks, vector_size=emd_size, window=10, min_count=0, sg=1, 
            workers=8, epochs=1)
    wv = model.wv
    embeddings = np.zeros([A.shape[0], emd_size], dtype='float32')
    sum_embeddings = 0
    empty_list = []
    for i in range(A.shape[0]):
        if str(i) in wv:
            embeddings[i] = wv.word_vec(str(i))
            sum_embeddings += embeddings[i]
        else:
            empty_list.append(i)
    mean_embedding = sum_embeddings / (A.shape[0] - len(empty_list))
    embeddings[empty_list] = mean_embedding
    return embeddings


def AA(A, test_pos, test_neg):
    # Adamic-Adar score
    A_ = A / np.log(A.sum(axis=1))
    A_[np.isnan(A_)] = 0
    A_[np.isinf(A_)] = 0
    sim = A.dot(A_)
    return CalcAUC(sim, test_pos, test_neg)
    
        
def CN(A, test_pos, test_neg):
    # Common Neighbor score
    sim = A.dot(A)
    return CalcAUC(sim, test_pos, test_neg)


def CalcAUC(sim, test_pos, test_neg):
    pos_scores = np.asarray(sim[test_pos[0], test_pos[1]]).squeeze()
    neg_scores = np.asarray(sim[test_neg[0], test_neg[1]]).squeeze()
    scores = np.concatenate([pos_scores, neg_scores])
    labels = np.hstack([np.ones(len(pos_scores)), np.zeros(len(neg_scores))])
    fpr, tpr, _ = metrics.roc_curve(labels, scores, pos_label=1)
    auc = metrics.auc(fpr, tpr)
    return auc



