from sklearn import metrics
import matplotlib.pyplot as plt

AUPR_1 = [0.96806, 0.96797, 0.96711, 0.96710, 0.96722, 0.96706, 0.96806, 0.96729, 0.96754, 0.96736]
AUPR_2 = [0.95542, 0.96009, 0.96094, 0.95762, 0.96234, 0.96125, 0.95773, 0.96011, 0.96005, 0.95917]
AUPR_3 = [0.85820, 0.91621, 0.88877, 0.91392, 0.89513, 0.91591, 0.89387, 0.91127, 0.90090, 0.90057]

Expeirmental_times = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

plt.plot(Expeirmental_times, AUPR_1, label = "Hop = 1", marker='o', markerfacecolor='black', markersize=5)
plt.plot(Expeirmental_times, AUPR_2, label = "Hop = 2", marker='o', markerfacecolor='black', markersize=5)
plt.plot(Expeirmental_times, AUPR_3, label = "Hop = 3", marker='o', markerfacecolor='black', markersize=5)
plt.ylabel('AUPR')
plt.xlabel('Experimental_Times')
plt.title("(b) AUPR with different Hop")
plt.legend(fontsize = 8.5)
plt.show()
plt.savefig('AUPR_Hop')



